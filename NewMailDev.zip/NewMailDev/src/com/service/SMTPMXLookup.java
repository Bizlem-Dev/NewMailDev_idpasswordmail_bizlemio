package com.service;


import java.io.*;
import java.net.*;
import java.security.cert.X509Certificate;
import java.util.*;
import javax.naming.*;
import javax.naming.directory.*;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class SMTPMXLookup {
  
     private static String getMX( String hostName )
         throws NamingException {
     // Perform a DNS lookup for MX records in the domain
    	 StringBuilder mailhost= null;
     Hashtable env = new Hashtable();
     env.put("java.naming.factory.initial",
             "com.sun.jndi.dns.DnsContextFactory");
     DirContext ictx = new InitialDirContext( env );
     Attributes attrs = ictx.getAttributes
                           ( hostName, new String[] { "MX" });
     Attribute attr = attrs.get( "MX" );

     // if we don't have an MX record, try the machine itself
     if (( attr == null ) || ( attr.size() == 0 )) {
       attrs = ictx.getAttributes( hostName, new String[] { "A" });
       attr = attrs.get( "A" );
       if( attr == null )
            throw new NamingException
                     ( "No match for name '" + hostName + "'" );
     }
         // Huzzah! we have machines to try. Return them as an array list
     // NOTE: We SHOULD take the preference into account to be absolutely
     //   correct. This is left as an exercise for anyone who cares.
     //ArrayList res = new ArrayList();
     NamingEnumeration en = attr.getAll();
     mailhost = new StringBuilder();
     while ( en.hasMore() ) {
        
        String x = (String) en.next();
        String f[] = x.split( " " );
        //  THE fix *************
        
        if (f.length == 1){
        	if(f[0].contains("google")){
        		mailhost.append("smtp.gmail.com");
        	}else if(f[0].contains("outlook")){
        		mailhost.append("smtp-mail.outlook.com");
        	}else if(f[0].contains("smtp.secureserver.net")){
        		mailhost.append("smtp.secureserver.net");
        	}else{
            mailhost.append(f[0]);
        	}
        break;
        }
        else if ( f[1].endsWith( "." ) ){
        	if(f[1].contains("google")){
        		mailhost.append("smtp.gmail.com");
        	}else if(f[1].contains("outlook")){
        		mailhost.append("smtp-mail.outlook.com");
        	}else if(f[1].contains("smtp.secureserver.net")){
        		mailhost.append("smtp.secureserver.net");
        	}else
        	{
            mailhost.append(f[1].substring( 0, (f[1].length() - 1)));
        	}
            break;
        	
        }
        else{
        	if(f[1].contains("google")){
        		mailhost.append("smtp.gmail.com");
        	}else if(f[1].contains("outlook")){
        		mailhost.append("smtp-mail.outlook.com");
        	}else if(f[1].contains("smtp.secureserver.net")){
        		mailhost.append("smtp.secureserver.net");
        	}else{
            mailhost.append(f[1]);
            
        	}break;
        }
        //  THE fix *************            
     //   res.add( mailhost );
     }
     return mailhost.toString();
     }

   public static String isAddressValid( String address ) {
     // Find the separator for the domain name
     int pos = address.indexOf( '@' );

     // If the address does not contain an '@', it's not valid
     if ( pos == -1 ) return "";

     // Isolate the domain/machine name and get a list of mail exchangers
     String domain = address.substring( ++pos );
     
     
     String mxList = null;
   
   
     try {
        /*mxList = getMX( domain );
        System.out.println("mxList:: "+mxList);*/
    	 
    	 ArrayList<String> al=new ArrayList<>();
    	 for (String mailHost: lookupMailHosts(domain))
    	 {
    	 System.out.println(mailHost);
    	 al.add(mailHost);
    	 }

    	 System.out.println(al);
    	 
    	 String requestURL="https://test.bluealgo.com:8083/portal/servlet/service/mailSendDynamicCheckHostname";
 		 HashMap<String, String> postDataParams=new HashMap<>();
 		 postDataParams.put("arrayString", al.toString());
 		 
 		 mxList=performPostCall(requestURL, postDataParams);
		 System.out.println(mxList);

    	/* Set<String> singleData = new HashSet<String>();

    	 for (String data : al) {
    	 if( data.contains("google") ){
    	 System.out.println("smtp.gmail.com");
    	 singleData.add("smtp.gmail.com");
    	 }else if( data.contains("outlook") ){
    	 System.out.println("smtp-mail.outlook.com");
    	 singleData.add("smtp-mail.outlook.com");
    	 }else if( data.contains("smtp.secureserver.net") ){
    	 System.out.println("smtp.secureserver.net");
    	 singleData.add("smtpout.secureserver.net");
    	 }
    	 }


    	 System.out.println("singleData:: "+singleData);
    	 Iterator<String> itr=singleData.iterator();
    	 while(itr.hasNext()) {
    	     mxList=itr.next();
    	 }*/
    	 
     }
     catch (NamingException ex) {
        return "";
     }
     
     
     return mxList;
     }
   
   public static String performPostCall(String requestURL,HashMap<String, String> postDataParams){

       URL url;
       String response = "";
       try {
           url = new URL(requestURL);

           ignoreHttps(requestURL);
           
           HttpURLConnection conn = (HttpURLConnection) url.openConnection();
           conn.setReadTimeout(15000);
           conn.setConnectTimeout(15000);
           conn.setRequestMethod("POST");
           conn.setDoInput(true);
           conn.setDoOutput(true);

           OutputStream os = conn.getOutputStream();
           BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
           writer.write(getPostDataString(postDataParams));

           writer.flush();
           writer.close();
           os.close();
           int responseCode=conn.getResponseCode();

           if (responseCode == HttpsURLConnection.HTTP_OK) {
               String line;
               BufferedReader br=new BufferedReader(new InputStreamReader(conn.getInputStream()));
               while ((line=br.readLine()) != null) {
                   response+=line;
               }
           }
           else {
               response="";

           }
       } catch (Exception e) {
           e.printStackTrace();
       }

       return response;
   }
   
   private static String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException{
       StringBuilder result = new StringBuilder();
       boolean first = true;
       for(Map.Entry<String, String> entry : params.entrySet()){
           if (first)
               first = false;
           else
               result.append("&");

           result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
           result.append("=");
           result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
       }

       return result.toString();
   }	
   
   public static void ignoreHttps(String urlstring){
		try{
		if(urlstring.indexOf("https:") != -1){
		TrustManager[] trustAllCerts = new TrustManager[] {
		new X509TrustManager() {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		return null;
		}

		public void checkClientTrusted(X509Certificate[] certs, String authType) { }

		public void checkServerTrusted(X509Certificate[] certs, String authType) { }

		}
		};


		try {
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
		public boolean verify(String hostname, SSLSession session) {
		return true;
		}
		};
		// Install the all-trusting host verifier
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		/*
		* end of the fix
		*/
		}
		}catch(Exception e){

		}
		}
   
   public static String[] lookupMailHosts(String domainName) throws NamingException
   {
       // see: RFC 974 - Mail routing and the domain system
       // see: RFC 1034 - Domain names - concepts and facilities
       // see: http://java.sun.com/j2se/1.5.0/docs/guide/jndi/jndi-dns.html
       //    - DNS Service Provider for the Java Naming Directory Interface (JNDI)

       // get the default initial Directory Context
       InitialDirContext iDirC = new InitialDirContext();
       // get the MX records from the default DNS directory service provider
       //    NamingException thrown if no DNS record found for domainName
       Attributes attributes = iDirC.getAttributes("dns:/" + domainName, new String[] {"MX"});
       // attributeMX is an attribute ('list') of the Mail Exchange(MX) Resource Records(RR)
       Attribute attributeMX = attributes.get("MX");

       // if there are no MX RRs then default to domainName (see: RFC 974)
       if (attributeMX == null)
       {
           return (new String[] {domainName});
       }

       // split MX RRs into Preference Values(pvhn[0]) and Host Names(pvhn[1])
       String[][] pvhn = new String[attributeMX.size()][2];
       for (int i = 0; i < attributeMX.size(); i++)
       {
           pvhn[i] = ("" + attributeMX.get(i)).split("\\s+");
       }

       // sort the MX RRs by RR value (lower is preferred)
       Arrays.sort(pvhn, new Comparator<String[]>()
           {
               public int compare(String[] o1, String[] o2)
               {
                   return (Integer.parseInt(o1[0]) - Integer.parseInt(o2[0]));
               }
           });

       // put sorted host names in an array, get rid of any trailing '.' 
       String[] sortedHostNames = new String[pvhn.length];
       for (int i = 0; i < pvhn.length; i++)
       {
           sortedHostNames[i] = pvhn[i][1].endsWith(".") ? 
               pvhn[i][1].substring(0, pvhn[i][1].length() - 1) : pvhn[i][1];
       }
       return sortedHostNames;
   }

   public static void main( String args[] ) {
     String testData[] = {
         "mohit.raj@bizlem.io",
         "mohitraj.ranu@gmail.com",
         "mohitraj.ranu@outlook.com"
         };

     for ( int ctr = 0 ; ctr < testData.length ; ctr++ ) {
      
            String mailhost =  isAddressValid( testData[ ctr ] );
            System.out.println("mailhost returned is "+mailhost);
     }
     }
} 
