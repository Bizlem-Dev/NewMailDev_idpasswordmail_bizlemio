package com.telcob.sms;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class SmsMethods {

	public static void main(String[] args) {

		/*String requestURL="http://app.telcob.cloud/app/smsapi/index.php";
		HashMap<String, String> postDataParams=new HashMap<>();
		postDataParams.put("key", "25E731F054E598");
		postDataParams.put("campaign", "0");
		postDataParams.put("routeid", "2"); //2 for promotional 
		postDataParams.put("type", "text");
		postDataParams.put("contacts", "315 636 3128");
		postDataParams.put("senderid", "DOCTER");
		
		//String msgBody=URLEncoder.encode("this is test msg", "UTF-8");
		
		postDataParams.put("msg", "this is test msg");
		
		String data=performPostCall(requestURL, postDataParams);
		System.out.println(data);*/
		
		/*String requestURL="https://bluealgo.com:8092/NewMailDev/SendSmsTelcob";
		HashMap<String, String> postDataParams=new HashMap<>();
		
		postDataParams.put("type", "text");
		postDataParams.put("contacts", "9619376212");  //9987630281  //7718892987 //7506272969  //8689877203
//		postDataParams.put("contacts", ""); // uk
		postDataParams.put("senderid", "BIZLEM");
		
		//String msgBody=URLEncoder.encode("this is test msg", "UTF-8");
		
		postDataParams.put("msg", "sms2 INV-102 , 17/03/2020 , 432467.67 , INR , 2020-03-21T07:25:00 , Cust102 , Ddee Contractors , Dee Address1");
		
		String data=performPostCall(requestURL, postDataParams);
		System.out.println(data);*/
		
		
		String requestURL="https://bluealgo.com:8092/NewMailDev/WhatsappSendMessage";
		HashMap<String, String> postDataParams=new HashMap<>();
	
		postDataParams.put("to", "+918689877203"); // uk    //+919619376212 //+917506272969
		postDataParams.put("bodyMsg", "multiple whatsapp number integrated.");
		
		String data=performPostCall(requestURL, postDataParams);
		System.out.println(data);
		
	}
	
	public static String  performPostCall(String requestURL,HashMap<String, String> postDataParams){

        URL url;
        String response = "";
        try {
            url = new URL(requestURL);

            ignoreHttps(requestURL);
            
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(getPostDataString(postDataParams));

            writer.flush();
            writer.close();
            os.close();
            int responseCode=conn.getResponseCode();

            if (responseCode == HttpsURLConnection.HTTP_OK) {
                String line;
                BufferedReader br=new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line=br.readLine()) != null) {
                    response+=line;
                }
            }
            else {
                response="";

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }

	private static String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException{
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for(Map.Entry<String, String> entry : params.entrySet()){
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }	

	public static void ignoreHttps(String urlstring){
		try{
		if(urlstring.indexOf("https:") != -1){
		TrustManager[] trustAllCerts = new TrustManager[] {
		new X509TrustManager() {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		return null;
		}

		public void checkClientTrusted(X509Certificate[] certs, String authType) { }

		public void checkServerTrusted(X509Certificate[] certs, String authType) { }

		}
		};


		try {
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		}

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
		public boolean verify(String hostname, SSLSession session) {
		return true;
		}
		};
		// Install the all-trusting host verifier
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		/*
		* end of the fix
		*/
		}
		}catch(Exception e){

		}
		}
    
	public static boolean isNullString(String p_text) {
		if (p_text != null && p_text.trim().length() > 0 && !"null".equalsIgnoreCase(p_text.trim())) {
			return false;
		} else {
			return true;
		}
	}
	

}
