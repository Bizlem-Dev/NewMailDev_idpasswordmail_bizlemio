package com.telcob.sms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SendSmsTelcob
 */
@WebServlet("/SendSmsTelcob")
public class SendSmsTelcob extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static ResourceBundle bundleststic = ResourceBundle.getBundle("config");
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendSmsTelcob() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/plain");
		
		String type=request.getParameter("type");
		String contacts=request.getParameter("contacts");
		String senderid=request.getParameter("senderid");
		String msg=request.getParameter("msg");
		
		try{
			
		boolean checkNotNullType=false;
		boolean checkNotNullContacts=false;
		boolean checkNotNullSenderid=false;
		boolean checkNotNullMsg=false;
		
		if( !SmsMethods.isNullString(type) ){
			 checkNotNullType=true;
		}else{
			out.println("parameter type cant't be blank.");
		}if( !SmsMethods.isNullString(contacts) ){
			 checkNotNullContacts=true;
		}else{
			out.println("parameter contacts cant't be blank.");
		}if( !SmsMethods.isNullString(senderid) ){
			 checkNotNullSenderid=true;
		}else{
			out.println("parameter senderid cant't be blank.");
		}if( !SmsMethods.isNullString(msg) ){
			 checkNotNullMsg=true;
		}else{
			out.println("parameter msg cant't be blank.");
		}
		
		if( checkNotNullType==true && checkNotNullContacts==true && checkNotNullSenderid==true && checkNotNullMsg==true  ){
			
			String key=bundleststic.getString("telcobsms_key");
			String campaign=bundleststic.getString("telcobsms_campaign");
			String routeid=bundleststic.getString("telcobsms_routeid");
			
			String requestURL=bundleststic.getString("telcobsmsurl");
			
			if( !SmsMethods.isNullString(requestURL) && !SmsMethods.isNullString(key) && !SmsMethods.isNullString(campaign) && !SmsMethods.isNullString(routeid)){
				
				HashMap<String, String> postDataParams=new HashMap<>();
				
				postDataParams.put("key", key);
				postDataParams.put("campaign", campaign);
				postDataParams.put("routeid", routeid); //2 for promotional 
				postDataParams.put("type", type);
				postDataParams.put("contacts", contacts);
				postDataParams.put("senderid", senderid);
				
				//String msgBody=URLEncoder.encode("this is test msg", "UTF-8");
				
				postDataParams.put("msg", msg);
				
				String data=SmsMethods.performPostCall(requestURL, postDataParams);
				out.println(data);
				
			}else{
				out.println("Please Provide Valid key or campaign or routeid or url.");
			}
			
			
		}
		
		}catch( Exception e ){
			e.printStackTrace(out);
		}
		
		//doGet(request, response);
	}

}
