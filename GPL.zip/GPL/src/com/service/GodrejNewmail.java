package com.service;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

/**
 * Servlet implementation class GodrejNewmail
 */
@WebServlet("/GodrejNewmail")
public class GodrejNewmail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GodrejNewmail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		response.getWriter().println(GodrejPostgres.getPostGresConnection());
		
		JSONObject allPKFKData = null;
		try{
		String webServiceJson="{\r\n" + 
					"\"webservice\" : {\"host\":\"ec2-23-23-50-231.compute-1.amazonaws.com\",\"databasename\":\"dfchgt5o680aok\",\"username\":\"ubb3mhh56quq28\",\"password\":\"p40b3519da1cda5a8064ad44a89f19aee833c231d97b5996ebd63ce3d059e8bbd\",\"port\":\"5432\",\"webservicetype\":\"database\",\"databasetype\":\"postgres\",\"schema\":\"salesforce\"},\r\n" + 
					"\"PK\":{\"field\":\"sfid\", \"object\":\"Propstrength__Application_Booking__c\",\"value\":\"a10O0000004iFWGIA2\"},\r\n" + 
					"\"FK\":[\r\n" + 
					"{\"field\":\"sfid\", \"object\":\"Propstrength__Projects__c\",\"pkfield\":\"propstrength__project__c\",\"pkobject\":\"Propstrength__Application_Booking__c\"},\r\n" + 
					"{\"field\":\"sfid\", \"object\":\"contact\",\"pkfield\":\"propstrength__primary_customer__c\",\"pkobject\":\"propstrength__application_booking__c\"}\r\n" + 
					"]\r\n" + 
					"}";
		//System.out.println(webServiceJson);
		JSONObject objAllJson = new JSONObject(webServiceJson);
		JSONObject objWebServiceJson = objAllJson.getJSONObject("webservice");
		if(objWebServiceJson.has("webservicetype") & objWebServiceJson.getString("webservicetype").equals("database") & objWebServiceJson.getString("databasetype").equals("postgres")){
		Connection conn = PostgresFetchDataPKFK.getPostGresConnection(objWebServiceJson.getString("host"), 
				objWebServiceJson.getString("databasename"), objWebServiceJson.getString("username"), objWebServiceJson.getString("password"), objWebServiceJson.getString("port"));
		String schema = "";
		String schemaTable = "";
		JSONObject pkObj = objAllJson.getJSONObject("PK");
		if(objWebServiceJson.has("schema")){
			if(!objWebServiceJson.getString("schema").equals("")){
			schema = objWebServiceJson.getString("schema")+"."+pkObj.getString("object");
			schemaTable = objWebServiceJson.getString("schema");
			}else{
				schema = pkObj.getString("object");
			}
		}else{
			schema = pkObj.getString("object");
		}
		  allPKFKData = PostgresFetchDataPKFK.getPKData(conn, pkObj.getString("field"), schema, pkObj.getString("value"),pkObj.getString("object"));
		  allPKFKData = PostgresFetchDataPKFK.getFkData(conn, allPKFKData, objAllJson.getJSONArray("FK"), schemaTable);
		  response.getWriter().println("alldata :: " + allPKFKData);
		}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
