package com.twillio.whatsapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.telcob.sms.SmsMethods;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

/**
 * Servlet implementation class TwillioWhatsappSendMessage
 */
@WebServlet("/WhatsappSendMessage")
public class TwillioWhatsappSendMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static ResourceBundle bundleststic = ResourceBundle.getBundle("config");
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TwillioWhatsappSendMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		response.setContentType("text/plain");
		
		String to=request.getParameter("to");
		String bodyMsg=request.getParameter("bodyMsg");
		
		try {
			
			if( !SmsMethods.isNullString(to) && !SmsMethods.isNullString(bodyMsg) ){
				 
				String ACCOUNT_SID=bundleststic.getString("twilliowhatsapp_ACCOUNT_SID");
				String AUTH_TOKEN=bundleststic.getString("twilliowhatsapp_AUTH_TOKEN");
				String fromNo=bundleststic.getString("twilliowhatsapp_fromNo");
				
				if( !SmsMethods.isNullString(ACCOUNT_SID) && !SmsMethods.isNullString(AUTH_TOKEN) && !SmsMethods.isNullString(fromNo)){
					
					Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
					
					String toSplit[]=null;
					if( to.indexOf(",")!=-1 ){
						toSplit = to.split(",");
						
                        for(int j=0;j<toSplit.length;j++){
							
                        	 to=toSplit[j];
                        	Message message = Message.creator(
        			                new com.twilio.type.PhoneNumber("whatsapp:"+to), //+918689877203
        			                new com.twilio.type.PhoneNumber(fromNo),   //+12015540944   //+1 415 523 8886  //+1 415 523 8886
        			                bodyMsg)
        			            .create();
        					
        					out.println(message.getSid());
                        	
						}

					}else{
						Message message = Message.creator(
				                new com.twilio.type.PhoneNumber("whatsapp:"+to), //+918689877203
				                new com.twilio.type.PhoneNumber(fromNo),   //+12015540944   //+1 415 523 8886  //+1 415 523 8886
				                bodyMsg)
				            .create();
						
						out.println(message.getSid());
					}
					
					
						
					
					
					
					
					
					
				}else{
					out.println("Please Provide Valid ACCOUNT_SID or AUTH_TOKEN or fromNo.");
				}
				
			}else{
				out.println("parameter to or bodyMsg cant't be blank.");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//doGet(request, response);
	}

}
